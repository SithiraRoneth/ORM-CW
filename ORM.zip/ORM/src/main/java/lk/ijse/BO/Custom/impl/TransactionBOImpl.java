package lk.ijse.BO.Custom.impl;

public class TransactionBOImpl {
}
