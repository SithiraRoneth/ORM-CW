package lk.ijse.Dto;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class AdminDTO {
    private String mail;
    private String password;
}
