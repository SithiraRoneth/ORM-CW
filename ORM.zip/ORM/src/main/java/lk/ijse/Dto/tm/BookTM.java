package lk.ijse.Dto.tm;

public class BookTM {
    private String id;
    private String name;
    private String type;
}
