package lk.ijse.DAO.Custom;

import lk.ijse.DAO.CrudDAO;
import lk.ijse.Entity.Admin;
import lk.ijse.Entity.User;

import java.util.List;

public interface AdminDAO extends CrudDAO<Admin,String>{
}
