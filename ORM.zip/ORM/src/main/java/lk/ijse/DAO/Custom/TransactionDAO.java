package lk.ijse.DAO.Custom;

import lk.ijse.DAO.CrudDAO;
import lk.ijse.Entity.Transaction;

public interface TransactionDAO extends CrudDAO<Transaction,String > {
}
