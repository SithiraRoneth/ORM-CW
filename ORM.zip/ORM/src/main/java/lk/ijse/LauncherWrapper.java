/* Created By Sithira Roneth
 * Date :3/3/24
 * Time :22:00
 * Project Name :ORM
 * */
package lk.ijse;

public class LauncherWrapper {
    public static void main(String[] args) {
        Launcher.main(args);
    }
}
